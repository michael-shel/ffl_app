import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./pages/signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'set-name',
    loadChildren: () => import('./pages/set-name/set-name.module').then( m => m.SetNamePageModule)
  },
  {
    path: 'set-email',
    loadChildren: () => import('./pages/set-email/set-email.module').then( m => m.SetEmailPageModule)
  },
  {
    path: 'set-industry',
    loadChildren: () => import('./pages/set-industry/set-industry.module').then( m => m.SetIndustryPageModule)
  },
  {
    path: 'set-activities',
    loadChildren: () => import('./pages/set-activities/set-activities.module').then( m => m.SetActivitiesPageModule)
  },
  {
    path: 'account',
    loadChildren: () => import('./pages/account/account.module').then( m => m.AccountPageModule)
  },
  {
    path: 'username',
    loadChildren: () => import('./pages/modals/username/username.module').then( m => m.UsernamePageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
