import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetActivitiesPageRoutingModule } from './set-activities-routing.module';

import { SetActivitiesPage } from './set-activities.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetActivitiesPageRoutingModule
  ],
  declarations: [SetActivitiesPage]
})
export class SetActivitiesPageModule {}
