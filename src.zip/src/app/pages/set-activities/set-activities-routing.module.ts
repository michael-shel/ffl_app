import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SetActivitiesPage } from './set-activities.page';

const routes: Routes = [
  {
    path: '',
    component: SetActivitiesPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SetActivitiesPageRoutingModule {}
