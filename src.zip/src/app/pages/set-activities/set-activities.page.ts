import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-activities',
  templateUrl: './set-activities.page.html',
  styleUrls: ['./set-activities.page.scss'],
})
export class SetActivitiesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
