import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-industry',
  templateUrl: './set-industry.page.html',
  styleUrls: ['./set-industry.page.scss'],
})
export class SetIndustryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
