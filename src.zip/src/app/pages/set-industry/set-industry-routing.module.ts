import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SetIndustryPage } from './set-industry.page';

const routes: Routes = [
  {
    path: '',
    component: SetIndustryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SetIndustryPageRoutingModule {}
