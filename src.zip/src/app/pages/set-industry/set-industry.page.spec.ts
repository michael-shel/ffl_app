import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetIndustryPage } from './set-industry.page';

describe('SetIndustryPage', () => {
  let component: SetIndustryPage;
  let fixture: ComponentFixture<SetIndustryPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetIndustryPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetIndustryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
