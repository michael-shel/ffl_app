import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetIndustryPageRoutingModule } from './set-industry-routing.module';

import { SetIndustryPage } from './set-industry.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetIndustryPageRoutingModule
  ],
  declarations: [SetIndustryPage]
})
export class SetIndustryPageModule {}
