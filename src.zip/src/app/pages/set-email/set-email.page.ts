import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service'

@Component({
  selector: 'app-set-email',
  templateUrl: './set-email.page.html',
  styleUrls: ['./set-email.page.scss'],
})
export class SetEmailPage implements OnInit {
  submitted = false;
  constructor(
    private router: Router,
    private authService: AuthService,
  ) { }

  ngOnInit() {
  }
  
  login(form: NgForm) {
    this.submitted = true;

    if (form.valid) {
      this.authService.login(form.value.phone, form.value.password).subscribe(
      data => {
        console.log("Logged In");
        this.router.navigateByUrl('/set-name');
      },
      error => {
        console.log(error);
      },
      () => {
        
      }
    );
      
    }
  }

}
