import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  submitted = false;
  constructor(

    private router: Router,
    private authService: AuthService,
  ) { }

  ngOnInit() {
  }
    onSignup(form: NgForm) {
    this.submitted = true;

    if (form.valid) {
           this.authService.signup(form.value.phone).subscribe(
      data => {
        console.log(data);
    //     this.authService.login(form.value.phone, form.value.password).subscribe(
    //      data => {
    //       console.log("Logged In");
          this.router.navigateByUrl('/set-email');
    //      },
    //    error => {
    //     console.log(error);
    //    },
    //    () => {
    //     }
    //  );
        // this.router.navigateByUrl('/login');
      },
      error => {
        console.log(error);
      },
      () => {
        // this.router.navigateByUrl('/set-name');
      }
    );
      
    }
  }

}
