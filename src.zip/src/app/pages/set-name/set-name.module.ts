import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SetNamePageRoutingModule } from './set-name-routing.module';

import { SetNamePage } from './set-name.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SetNamePageRoutingModule
  ],
  declarations: [SetNamePage]
})
export class SetNamePageModule {}
