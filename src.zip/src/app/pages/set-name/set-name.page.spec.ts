import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SetNamePage } from './set-name.page';

describe('SetNamePage', () => {
  let component: SetNamePage;
  let fixture: ComponentFixture<SetNamePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetNamePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SetNamePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
