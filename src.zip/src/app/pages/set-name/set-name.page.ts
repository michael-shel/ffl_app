import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../services/auth.service'

@Component({
  selector: 'app-set-name',
  templateUrl: './set-name.page.html',
  styleUrls: ['./set-name.page.scss'],
})
export class SetNamePage implements OnInit {
  submitted = false;

  constructor(
    private router: Router,
    private authService: AuthService,
  ) { }

  ngOnInit() {
  }

    onSubmit(form: NgForm) {
      this.submitted = true;
      this.authService.setName(form.value.first_name, form.value.last_name).subscribe(
        
        data => {
          console.log("Name set!");
          
          this.router.navigateByUrl('/account');
        },

        error => {
          console.log(error);
        },

        () => {
          // this.router.navigateByUrl('/set-email');
        }
      );
    }


}
