import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service'
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  submitted = false;
  phoneCodes = [
    {
      country: "Ukraine",
      value:"+380",
      selected:true
    },
    {
      country: "Ukraine",
      value:"+380"
    },
    {
      country: "Ukraine",
      value:"+380"
    },
  ];
  constructor(
    private authService: AuthService,
    private router: Router,
  ) { }

  ngOnInit() {
    }

    // googleAuth(){
    //   this.authService.googleAuth();
    // }

    // facebookAuth(){
    //   this.authService.facebookAuth();
    // }

  login(form: NgForm) {
    this.submitted = true;

    if (form.valid) {
      this.authService.login(form.value.phone, form.value.password).subscribe(
      data => {
        console.log("Logged In");
      },
      error => {
        console.log(error);
      },
      () => {
        this.router.navigateByUrl('/account');
      }
    );
      
    }
  }

  signUp() {
    this.router.navigateByUrl('/signup');
  }

}
