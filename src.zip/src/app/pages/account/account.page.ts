
import { Component, OnInit } from '@angular/core';
import { Storage } from '@ionic/storage';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { AuthService } from '../../services/auth.service'
import { BehaviorSubject, Observable, of } from 'rxjs';
import { Router } from '@angular/router';
import { ActionSheetController } from '@ionic/angular';
import { Crop } from '@ionic-native/crop/ngx';
import { ImagePicker } from '@ionic-native/image-picker/ngx';
import { File } from '@ionic-native/file/ngx';
import { User } from '../../services/user';
import { ModalController } from '@ionic/angular';
import { UsernamePage } from '../modals/username/username.page';



@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss'],
})
export class AccountPage implements OnInit {
  // user:any = {};
  user : User;
  user$: Observable<User | null>;

  constructor(
    private storage: Storage,
    private camera: Camera,
    private authService: AuthService,
    private router: Router,
    public actionSheetController: ActionSheetController,
    private crop: Crop,
    private imagePicker: ImagePicker,
    private file: File,
    private modalController: ModalController,
  ) {
    this.user$ = authService.watchUser();
   }

  ngOnInit(): void { 
    // this.user = this.authService.user;
    // console.log(this.authService.user);
    this.user$.subscribe((data) => {
    this.user = data;
    });
   }

    updateProfile(): void { this.authService.pokeUser(this.user); }

    async presentModal() {
    const modal = await this.modalController.create({
      component: UsernamePage,
      componentProps: {
        username: this.user["phone"]
      }
    });
    modal.onWillDismiss().then(data => {
      this.user["phone"] = data.data;
      this.updateProfile();
      this.storage.set('user', this.user);

    })
    return await modal.present();
  }

  async getUser(){
    console.log(this.storage.get('user'));
    // window.dispatchEvent(new CustomEvent('user:update'));
  }
  
  async selectImage() {
    const actionSheet = await this.actionSheetController.create({
      header: "Select Image source",
      buttons: [{
        text: 'Load from Library',
        handler: () => {
          this.pickImage(this.camera.PictureSourceType.PHOTOLIBRARY);
        }
      },
      {
        text: 'Use Camera',
        handler: () => {
          console.log('camera')
        }
      },
      {
        text: 'Cancel',
        role: 'cancel'
      }
      ]
    });
    await actionSheet.present();
  }

    pickImage(sourceType) {
    const options: CameraOptions = {
      quality: 100,
      sourceType: sourceType,
      destinationType: this.camera.DestinationType.FILE_URI,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    }
    this.camera.getPicture(options).then((imageData) => {
      // imageData is either a base64 encoded string or a file URI
      // If it's base64 (DATA_URL):
      // let base64Image = 'data:image/jpeg;base64,' + imageData;
      this.cropImage(imageData)
    }, (err) => {
      // Handle error
    });
  }
  cropImage(fileUrl) {
    this.crop.crop(fileUrl, { quality: 50 })
      .then(
        newPath => {
          this.showCroppedImage(newPath.split('?')[0])
        },
        error => {
          alert('Error cropping image' + error);
        }
      );
  }

  showCroppedImage(ImagePath) {

    var copyPath = ImagePath;
    var splitPath = copyPath.split('/');
    var imageName = splitPath[splitPath.length - 1];
    var filePath = ImagePath.split(imageName)[0];

    this.file.readAsDataURL(filePath, imageName).then(base64 => {
      this.user.avatar = base64;
    }, error => {
      alert('Error in showing image' + error);
    });
  }

  logout(){
    this.authService.logout().then(() => {
      // this.authService.googleLogout();
      // this.authService.facebookLogout();
        this.router.navigate(['/']);
    })
  }

}
