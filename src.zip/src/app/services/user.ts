export interface User {
  id: number;
  avatar: string;
  phone: string;
  first_name: string;
  bio: string;
  company_id: string;
  country_id: string;
  created_at: string;
  deleted_at: null
  email: string;
  email_verified_at: string;
  industry_id: string;
  last_name: string;
  nickname: string;
  role_id: string;
  rsa_key_private: string;
  rsa_key_public: string;
  seniority_id: string;
  sex: string;
  status: number;
  title: string;
  updated_at: string;
}
