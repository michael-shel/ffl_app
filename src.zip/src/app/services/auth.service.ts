import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Storage } from '@ionic/storage';
import { tap,map } from 'rxjs/operators';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { EnvService } from './env.service';
// import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook/ngx';
// import { GooglePlus } from '@ionic-native/google-plus/ngx';
import { User } from './user';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  token: string;
  user: User;

  user$ = new BehaviorSubject<User | null>(null);  
  watchUser(): Observable<User | null> { return this.user$; }
  peekUser(): User | null { return this.user$.value; }
  pokeUser(user: User): void { this.user$.next(user); }

  constructor(
    private storage: Storage,
    private http: HttpClient,
    private env: EnvService,
    // private fb: Facebook,
    // private googlePlus: GooglePlus,
  ) { }

     login (phone: String, password: String) {
        return this.http.post(this.env.API_URL + 'login',
        {phone: phone, password: password}
         ).pipe(
         tap(data => {
          
          this.storage.set('token', data['token']);
          this.storage.set('user', data['user']);
          this.token = data['token'];
          // this.user = data['user'];
          this.pokeUser(data['user']);
          // console.log('this.watchUser() down: ');
          // console.log(this.watchUser());
          // return window.dispatchEvent(new CustomEvent('user:update'));
        }),
       )
      } 

    // googleAuth(){
    //   this.googlePlus.login({})
    //   .then((res)=>{
    //     this.googleAuth = res;
    //     console.log(res);
    //   },(err)=>{  
    //   })
    //   // .catch(err => console.error(err));
    // }

      getUser() {
        this.storage.get('user').then(val => {
          return val;
        });
      }

    //  googleLogout(){
    //   this.googlePlus.logout().then(() => {
    //     console.log('Google logout');
    //   })
    //   .catch(e => console.log('Error logout Google', e));
    //   }

    // facebookAuth(){
    //   this.fb.login(['public_profile', 'email'])
    //  .then((res: FacebookLoginResponse) => {
    // if(res.status==='connected'){
    //   // this.user.img = 'https://graph.facebook.com'+res.authResponse.userID+'/picture?type=square';
    //   this.fbData(res.authResponse.accessToken);
    //   }
    // else{
    //   alert('login failed');
    // }
  
    //   console.log('Logged into Facebook!', res)
    //   })
    //   .catch(e => console.log('Error logging into Facebook', e));
    // }

    // fbData(access_token:string){
    // let url = 'https://graph.facebook.com/me?fields=id,name,first_name,last_name,email&access_token=' + access_token;
    // this.http.get(url).subscribe(data => {
    // console.log(data);
    // });
    // }

    // facebookLogout(){
    //   this.fb.logout().then(() => {
    //     console.log('Facebook logout');
    //   })
    //   .catch(e => console.log('Error logout Facebook', e));
    //   }

    
    async storageUser(data){
     await this.storage.set('user', data);
     this.pokeUser(data);
    }

    signup(phone: String) {
      return this.http.post(this.env.API_URL + 'register',
        {phone: phone}
        // ).pipe(
        // map(data => {
          // return window.dispatchEvent(new CustomEvent('user:update'));
        // }),
      );
    }

    setName(first_name: String, last_name: String){
    const headers = new HttpHeaders({
      'Authorization': this.token["token_type"]+" "+this.token["token"]
    });

    return this.http.post(
      this.env.API_URL + 'userData',
      {first_name: first_name, last_name: last_name },
      {headers: headers}
      ).pipe(
      tap(data => {
        this.storageUser(data);
        
      }),
    );
  }

    logout(): Promise<any> {
    return this.storage.remove('token').then(() => {
      return this.storage.remove('user');
      return window.dispatchEvent(new CustomEvent('user:logout'));
    });
  }

}
